package com.example.projf_confplain

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
