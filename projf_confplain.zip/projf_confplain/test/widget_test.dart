import 'package:flutter_test/flutter_test.dart';
import 'package:projf_confplain/main.dart';

void main() {
	testWidgets('exibe a tela de login', (tester) async {
		await tester.pumpWidget(const SoftMakeApp());

		expect(find.text('Acessar sistema'), findsOneWidget);
		expect(find.text('Entrar'), findsOneWidget);
	});
}
