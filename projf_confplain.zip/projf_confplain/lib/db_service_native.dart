import 'dart:convert';

import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class AppDatabase {
  AppDatabase._();

  static final AppDatabase instance = AppDatabase._();
  Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;
    final databasePath = await getDatabasesPath();
    _database = await openDatabase(
      join(databasePath, 'softmake.db'),
      version: 1,
      onCreate: (database, version) async {
        await database.execute('''
          CREATE TABLE records (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            module TEXT NOT NULL,
            values_json TEXT NOT NULL,
            created_at TEXT NOT NULL
          )
        ''');
      },
    );
    return _database!;
  }

  Future<int> insertRecord(String module, List<String> values) async {
    return (await database).insert('records', {
      'module': module,
      'values_json': jsonEncode(values),
      'created_at': DateTime.now().toIso8601String(),
    });
  }

  Future<List<Map<String, dynamic>>> getRecords(String module) async {
    return (await database).query('records', where: 'module = ?', whereArgs: [module], orderBy: 'id DESC');
  }

  Future<int> updateRecord(int id, List<String> values) async {
    return (await database).update('records', {'values_json': jsonEncode(values)}, where: 'id = ?', whereArgs: [id]);
  }

  Future<int> deleteRecord(int id) async {
    return (await database).delete('records', where: 'id = ?', whereArgs: [id]);
  }
}