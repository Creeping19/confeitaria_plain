import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:projf_confplain/db_service.dart';

void main() {
	runApp(const SoftMakeApp());
}

class SoftMakeApp extends StatelessWidget {
	const SoftMakeApp({super.key});

	@override
	Widget build(BuildContext context) {
		return MaterialApp(
			title: 'SoftMake Gestão',
			debugShowCheckedModeBanner: false,
			theme: ThemeData(
				useMaterial3: true,
				colorScheme: ColorScheme.fromSeed(
					seedColor: const Color(0xFF5C1E91),
					brightness: Brightness.light,
				),
				scaffoldBackgroundColor: const Color(0xFFF7F7FB),
				fontFamily: 'Roboto',
				inputDecorationTheme: InputDecorationTheme(
					filled: true,
					fillColor: Colors.white,
					border: OutlineInputBorder(
						borderRadius: BorderRadius.circular(12),
						borderSide: BorderSide.none,
					),
					enabledBorder: OutlineInputBorder(
						borderRadius: BorderRadius.circular(12),
						borderSide: const BorderSide(color: Color(0xFFE6E1EA)),
					),
					focusedBorder: OutlineInputBorder(
						borderRadius: BorderRadius.circular(12),
						borderSide: const BorderSide(color: Color(0xFF7629A9), width: 1.5),
					),
				),
			),
			home: const LoginPage(),
		);
	}
}

enum UserRole { owner, cashier, attendant }

extension UserRoleDetails on UserRole {
	String get label => switch (this) {
			UserRole.owner => 'Proprietário',
			UserRole.cashier => 'Caixa',
			UserRole.attendant => 'Atendente',
		};
	String get username => switch (this) {
			UserRole.owner => 'proprietario',
			UserRole.cashier => 'caixa',
			UserRole.attendant => 'atendente',
		};
	String get name => switch (this) {
			UserRole.owner => 'Mariana Alves',
			UserRole.cashier => 'Carlos Souza',
			UserRole.attendant => 'Ana Lima',
		};
	String get initials => switch (this) {
			UserRole.owner => 'MA',
			UserRole.cashier => 'CS',
			UserRole.attendant => 'AL',
		};
}

Set<AppPage> pagesForRole(UserRole role) => switch (role) {
	UserRole.owner => AppPage.values.toSet(),
	UserRole.cashier => {AppPage.overview, AppPage.customers, AppPage.sales, AppPage.cash},
	UserRole.attendant => {AppPage.overview, AppPage.products, AppPage.customers, AppPage.sales, AppPage.stock, AppPage.cash},
};

class LoginPage extends StatefulWidget {
	const LoginPage({super.key});

	@override
	State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
	final usernameController = TextEditingController(text: 'proprietario');
	final passwordController = TextEditingController();
	UserRole selectedRole = UserRole.owner;
	bool obscurePassword = true;
	String? errorMessage;

	void _selectRole(UserRole role) {
		setState(() {
			selectedRole = role;
			usernameController.text = role.username;
			errorMessage = null;
		});
	}

	void _login() {
		if (usernameController.text.trim().toLowerCase() == selectedRole.username && passwordController.text == '1234') {
			Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => MainShell(role: selectedRole)));
		} else {
			setState(() => errorMessage = 'Usuário ou senha inválidos para este perfil.');
		}
	}

	@override
	Widget build(BuildContext context) {
		return Scaffold(
			body: Container(
				decoration: const BoxDecoration(gradient: LinearGradient(colors: [Color(0xFF261032), Color(0xFF5C1E91)], begin: Alignment.topLeft, end: Alignment.bottomRight)),
				child: Center(
					child: SingleChildScrollView(
						padding: const EdgeInsets.all(22),
						child: ConstrainedBox(
							constraints: const BoxConstraints(maxWidth: 440),
							child: Container(
								padding: const EdgeInsets.all(30),
								decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(22), boxShadow: const [BoxShadow(color: Color(0x440E0714), blurRadius: 35, offset: Offset(0, 18))]),
								child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
									Center(child: Image.asset('assets/images/softmake_logo.png', width: 260, height: 110, fit: BoxFit.contain)),
									const SizedBox(height: 30),
									const Text('Acessar sistema', style: TextStyle(color: Color(0xFF302137), fontSize: 22, fontWeight: FontWeight.w800)),
									const SizedBox(height: 5),
									const Text('Selecione seu perfil para continuar', style: TextStyle(color: Color(0xFF837687), fontSize: 12)),
									const SizedBox(height: 18),
									SizedBox(width: double.infinity, child: SegmentedButton<UserRole>(segments: const [ButtonSegment(value: UserRole.owner, label: Text('Proprietário')), ButtonSegment(value: UserRole.cashier, label: Text('Caixa')), ButtonSegment(value: UserRole.attendant, label: Text('Atendente'))], selected: {selectedRole}, onSelectionChanged: (roles) => _selectRole(roles.first))),
									const SizedBox(height: 18),
									TextField(controller: usernameController, decoration: const InputDecoration(labelText: 'Usuário', prefixIcon: Icon(Icons.person_outline))),
									const SizedBox(height: 13),
									TextField(controller: passwordController, obscureText: obscurePassword, onSubmitted: (_) => _login(), decoration: InputDecoration(labelText: 'Senha', prefixIcon: const Icon(Icons.lock_outline), suffixIcon: IconButton(onPressed: () => setState(() => obscurePassword = !obscurePassword), icon: Icon(obscurePassword ? Icons.visibility_outlined : Icons.visibility_off_outlined)))),
									if (errorMessage != null) ...[const SizedBox(height: 10), Text(errorMessage!, style: const TextStyle(color: Color(0xFFB3261E), fontSize: 12))],
									const SizedBox(height: 20),
									SizedBox(width: double.infinity, height: 48, child: FilledButton.icon(onPressed: _login, icon: const Icon(Icons.login_rounded, size: 19), label: const Text('Entrar'))),
									const SizedBox(height: 18),
									Center(child: Text('Acesso demonstrativo: senha 1234', style: TextStyle(color: Colors.grey.shade600, fontSize: 11))),
								]),
							),
						),
					),
				),
			),
		);
	}
}

class NavItem {
	const NavItem(this.label, this.icon, this.page);

	final String label;
	final IconData icon;
	final AppPage page;
}

enum AppPage { overview, users, products, customers, suppliers, sales, stock, cash, reports, management, charter }

const navItems = [
	NavItem('Visão geral', Icons.grid_view_rounded, AppPage.overview),
	NavItem('Usuários', Icons.people_alt_outlined, AppPage.users),
	NavItem('Produtos', Icons.inventory_2_outlined, AppPage.products),
	NavItem('Clientes', Icons.badge_outlined, AppPage.customers),
	NavItem('Fornecedores', Icons.local_shipping_outlined, AppPage.suppliers),
	NavItem('Vendas', Icons.shopping_bag_outlined, AppPage.sales),
	NavItem('Estoque', Icons.warehouse_outlined, AppPage.stock),
	NavItem('Caixa', Icons.point_of_sale_outlined, AppPage.cash),
	NavItem('Relatórios', Icons.bar_chart_rounded, AppPage.reports),
	NavItem('Gerência', Icons.admin_panel_settings_outlined, AppPage.management),
	NavItem('Termo de abertura', Icons.description_outlined, AppPage.charter),
];

class MainShell extends StatefulWidget {
	const MainShell({required this.role, super.key});

	final UserRole role;

	@override
	State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
	AppPage selectedPage = AppPage.overview;

	List<NavItem> get availableItems => navItems.where((item) => pagesForRole(widget.role).contains(item.page)).toList();
	int get selectedIndex => availableItems.indexWhere((item) => item.page == selectedPage);

	void selectPage(AppPage page) {
		setState(() => selectedPage = page);
	}

	@override
	Widget build(BuildContext context) {
		final isCompact = MediaQuery.sizeOf(context).width < 900;
		final page = navItems.firstWhere((item) => item.page == selectedPage);

		return Scaffold(
			drawer: isCompact
					? Drawer(
							child: SafeArea(
								child: SideNavigation(role: widget.role, selectedPage: selectedPage, onSelected: (value) {
									selectPage(value);
									Navigator.pop(context);
								}),
							),
						)
					: null,
			body: Row(
				children: [
					if (!isCompact)
						SizedBox(
							width: 252,
							child: SideNavigation(role: widget.role, selectedPage: selectedPage, onSelected: selectPage),
						),
					Expanded(
						child: Column(
							children: [
								_TopBar(title: page.label, role: widget.role, compact: isCompact),
								Expanded(
									child: AnimatedSwitcher(
										duration: const Duration(milliseconds: 250),
										child: _PageContent(key: ValueKey(selectedPage), page: selectedPage, role: widget.role),
									),
								),
							],
						),
					),
				],
			),
			bottomNavigationBar: isCompact
					? NavigationBar(
							selectedIndex: selectedIndex.clamp(0, availableItems.length.clamp(1, 4) - 1),
							onDestinationSelected: (index) => selectPage(availableItems.take(4).elementAt(index).page),
							destinations: availableItems.take(4).map((item) => NavigationDestination(icon: Icon(item.icon), label: item.label)).toList(),
						)
					: null,
		);
	}
}

class SideNavigation extends StatelessWidget {
	const SideNavigation({required this.role, required this.selectedPage, required this.onSelected, super.key});

	final UserRole role;
	final AppPage selectedPage;
	final ValueChanged<AppPage> onSelected;

	@override
	Widget build(BuildContext context) {
		return Container(
			color: const Color(0xFF24112F),
			padding: const EdgeInsets.fromLTRB(16, 22, 16, 18),
			child: Column(
				crossAxisAlignment: CrossAxisAlignment.start,
				children: [
					Padding(
						padding: const EdgeInsets.only(left: 8, bottom: 26),
						child: Row(
							children: [
								Container(
									width: 38,
									height: 38,
									decoration: BoxDecoration(
										gradient: const LinearGradient(colors: [Color(0xFFCD63F2), Color(0xFF6E23A9)]),
										borderRadius: BorderRadius.circular(11),
									),
									child: const Icon(Icons.trending_up_rounded, color: Colors.white, size: 25),
								),
								const SizedBox(width: 10),
								const Text('SOFTMAKE', style: TextStyle(color: Colors.white, fontSize: 19, fontWeight: FontWeight.w800, letterSpacing: 1.2)),
							],
						),
					),
					const Padding(
						padding: EdgeInsets.only(left: 10, bottom: 10),
						child: Text('MENU PRINCIPAL', style: TextStyle(color: Color(0xFFAF9BB9), fontSize: 10, fontWeight: FontWeight.w700, letterSpacing: 1.4)),
					),
					Expanded(
						child: ListView.separated(
							itemCount: navItems.where((item) => pagesForRole(role).contains(item.page)).length,
							separatorBuilder: (_, _) => const SizedBox(height: 3),
							itemBuilder: (context, index) {
								final item = navItems.where((item) => pagesForRole(role).contains(item.page)).elementAt(index);
								final isSelected = item.page == selectedPage;
								return ListTile(
									onTap: () => onSelected(item.page),
									selected: isSelected,
									shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
									selectedTileColor: const Color(0xFF6B2A89),
									leading: Icon(item.icon, size: 20, color: isSelected ? Colors.white : const Color(0xFFC9BBD0)),
									title: Text(item.label, style: TextStyle(color: isSelected ? Colors.white : const Color(0xFFC9BBD0), fontSize: 13, fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500)),
									contentPadding: const EdgeInsets.symmetric(horizontal: 12),
									dense: true,
								);
							},
						),
					),
					const Divider(color: Color(0xFF4A3555)),
					ListTile(
						contentPadding: const EdgeInsets.symmetric(horizontal: 8),
						leading: CircleAvatar(backgroundColor: const Color(0xFFE7B35C), child: Text(role.initials, style: const TextStyle(color: Color(0xFF44240C), fontSize: 11, fontWeight: FontWeight.bold))),
						title: Text(role.name, style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w700)),
						subtitle: Text(role.label, style: const TextStyle(color: Color(0xFFAF9BB9), fontSize: 11)),
						trailing: IconButton(onPressed: () {}, icon: const Icon(Icons.more_vert, color: Color(0xFFAF9BB9), size: 18)),
					),
				],
			),
		);
	}
}

class _TopBar extends StatelessWidget {
	const _TopBar({required this.title, required this.role, required this.compact});

	final String title;
	final UserRole role;
	final bool compact;

	@override
	Widget build(BuildContext context) {
		return Container(
			height: 76,
			padding: EdgeInsets.symmetric(horizontal: compact ? 16 : 30),
			decoration: const BoxDecoration(color: Colors.white, border: Border(bottom: BorderSide(color: Color(0xFFECE9F0)))),
			child: Row(
				children: [
					if (compact) ...[
						Builder(builder: (context) => IconButton(onPressed: () => Scaffold.of(context).openDrawer(), icon: const Icon(Icons.menu_rounded))),
						const SizedBox(width: 4),
					],
					IconButton(
						onPressed: () => Navigator.of(context).pushAndRemoveUntil(
							MaterialPageRoute(builder: (_) => const LoginPage()),
							(route) => false,
						),
						tooltip: 'Voltar para o login e trocar usuário',
						icon: const Icon(Icons.arrow_back_rounded),
					),
					const SizedBox(width: 4),
					Text(title, style: const TextStyle(color: Color(0xFF2C1A35), fontSize: 20, fontWeight: FontWeight.w800)),
					const Spacer(),
					if (!compact)
						SizedBox(
							width: 245,
							height: 40,
							child: TextField(decoration: const InputDecoration(hintText: 'Buscar no sistema', prefixIcon: Icon(Icons.search, size: 19), contentPadding: EdgeInsets.symmetric(vertical: 8))),
						),
					const SizedBox(width: 12),
					IconButton(onPressed: () {}, tooltip: 'Notificações', icon: const Badge(label: Text('3'), child: Icon(Icons.notifications_none_rounded))),
					const SizedBox(width: 4),
					CircleAvatar(radius: 17, backgroundColor: const Color(0xFFE7B35C), child: Text(role.initials, style: const TextStyle(color: Color(0xFF44240C), fontSize: 10, fontWeight: FontWeight.bold))),
				],
			),
		);
	}
}

class _PageContent extends StatelessWidget {
	const _PageContent({required this.page, required this.role, super.key});

	final AppPage page;
	final UserRole role;

	@override
	Widget build(BuildContext context) {
		if (page == AppPage.overview) return const DashboardPage();
		if (page == AppPage.charter) return const CharterPage();
		return ModulePage(type: page, role: role);
	}
}

class DashboardPage extends StatelessWidget {
	const DashboardPage({super.key});

	@override
	Widget build(BuildContext context) {
		return LayoutBuilder(builder: (context, constraints) {
			final columns = constraints.maxWidth > 1100 ? 4 : constraints.maxWidth > 650 ? 2 : 1;
			return SingleChildScrollView(
				padding: EdgeInsets.all(constraints.maxWidth < 600 ? 16 : 30),
				child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
					Container(
						width: double.infinity,
						padding: const EdgeInsets.all(24),
						decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF542080), Color(0xFF823CA7)], begin: Alignment.topLeft, end: Alignment.bottomRight), borderRadius: BorderRadius.circular(16)),
						child: Row(children: [
							Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: const [Text('Bom dia, Mariana!', style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w800)), SizedBox(height: 7), Text('Acompanhe a operação da SoftMake em um só lugar.', style: TextStyle(color: Color(0xFFEBDDF2), fontSize: 13))])),
							if (constraints.maxWidth > 550) const Icon(Icons.auto_graph_rounded, color: Color(0x66FFFFFF), size: 75),
						]),
					),
					const SizedBox(height: 25),
					const Text('Resumo de hoje', style: TextStyle(color: Color(0xFF2C1A35), fontSize: 17, fontWeight: FontWeight.w800)),
					const SizedBox(height: 13),
					GridView.count(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), crossAxisCount: columns, crossAxisSpacing: 14, mainAxisSpacing: 14, childAspectRatio: columns == 1 ? 3.3 : 1.55, children: const [
						MetricCard(label: 'Vendas hoje', value: 'R\$ 8.420,00', detail: '+12,5% vs. ontem', icon: Icons.trending_up_rounded, color: Color(0xFF16866C)),
						MetricCard(label: 'Pedidos realizados', value: '68', detail: '+8 pedidos', icon: Icons.shopping_bag_outlined, color: Color(0xFF6B35A0)),
						MetricCard(label: 'Estoque baixo', value: '12 itens', detail: 'Atenção necessária', icon: Icons.warning_amber_rounded, color: Color(0xFFD78322)),
						MetricCard(label: 'Clientes ativos', value: '1.248', detail: '+24 este mês', icon: Icons.people_alt_outlined, color: Color(0xFF2D79A7)),
					]),
					const SizedBox(height: 25),
					Wrap(spacing: 18, runSpacing: 18, children: [
						SizedBox(width: constraints.maxWidth > 850 ? constraints.maxWidth * .57 : constraints.maxWidth, child: const SalesPanel()),
						SizedBox(width: constraints.maxWidth > 850 ? constraints.maxWidth * .37 : constraints.maxWidth, child: const ActivityPanel()),
					]),
				]),
			);
		});
	}
}

class MetricCard extends StatelessWidget {
	const MetricCard({required this.label, required this.value, required this.detail, required this.icon, required this.color, super.key});
	final String label, value, detail;
	final IconData icon;
	final Color color;

	@override
	Widget build(BuildContext context) {
		return Container(
			padding: const EdgeInsets.all(17),
			decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14), border: Border.all(color: const Color(0xFFE9E5ED))),
			child: Row(
				children: [
					Container(padding: const EdgeInsets.all(10), decoration: BoxDecoration(color: color.withValues(alpha: .11), borderRadius: BorderRadius.circular(11)), child: Icon(icon, color: color, size: 23)),
					const SizedBox(width: 12),
					Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [Text(label, style: const TextStyle(color: Color(0xFF796D80), fontSize: 11)), const SizedBox(height: 4), Text(value, style: const TextStyle(color: Color(0xFF302137), fontSize: 19, fontWeight: FontWeight.w800)), const SizedBox(height: 3), Text(detail, style: TextStyle(color: color, fontSize: 10, fontWeight: FontWeight.w700))])),
				],
			),
		);
	}
}

class SalesPanel extends StatelessWidget {
	const SalesPanel({super.key});
	@override
	Widget build(BuildContext context) {
		return _WhitePanel(
			title: 'Desempenho de vendas',
			action: 'Últimos 7 dias',
			child: SizedBox(
				height: 190,
				child: CustomPaint(
					painter: SalesChartPainter(),
					child: const Padding(
						padding: EdgeInsets.only(left: 8, bottom: 3),
						child: Align(
							alignment: Alignment.bottomLeft,
							child: Text(
								'Seg.     Ter.     Qua.     Qui.     Sex.     Sáb.     Dom.',
								style: TextStyle(color: Color(0xFF918995), fontSize: 10),
							),
						),
					),
				),
			),
		);
	}
}

class SalesChartPainter extends CustomPainter {
	@override
	void paint(Canvas canvas, Size size) {
		final grid = Paint()..color = const Color(0xFFEDE9F0)..strokeWidth = 1;
		for (var i = 1; i < 5; i++) {
			canvas.drawLine(Offset(0, i * size.height / 5), Offset(size.width, i * size.height / 5), grid);
		}
		final line = Paint()..color = const Color(0xFF702DA0)..strokeWidth = 3..style = PaintingStyle.stroke..strokeCap = StrokeCap.round;
		final points = [0.68, 0.56, 0.73, 0.42, 0.48, 0.25, 0.34];
		final path = Path();
		for (var i = 0; i < points.length; i++) {
			final point = Offset(i * size.width / (points.length - 1), points[i] * size.height);
			if (i == 0) {
				path.moveTo(point.dx, point.dy);
			} else {
				path.lineTo(point.dx, point.dy);
			}
			canvas.drawCircle(point, 4, Paint()..color = Colors.white);
			canvas.drawCircle(point, 3, Paint()..color = const Color(0xFF702DA0));
		}
		canvas.drawPath(path, line);
	}
	@override
	bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class ActivityPanel extends StatelessWidget {
	const ActivityPanel({super.key});
	@override
	Widget build(BuildContext context) => _WhitePanel(title: 'Atividade recente', action: 'Ver tudo', child: Column(children: const [ActivityRow(icon: Icons.shopping_bag_outlined, color: Color(0xFF6B35A0), title: 'Nova venda registrada', detail: 'Venda #00482 · há 8 min'), ActivityRow(icon: Icons.person_add_alt_1_outlined, color: Color(0xFF2D79A7), title: 'Novo cliente cadastrado', detail: 'Ricardo Mendes · há 21 min'), ActivityRow(icon: Icons.warning_amber_rounded, color: Color(0xFFD78322), title: 'Estoque abaixo do mínimo', detail: 'Café especial 500g · há 1 h'), ActivityRow(icon: Icons.inventory_2_outlined, color: Color(0xFF16866C), title: 'Entrada de estoque', detail: 'Fornecedor Café Bom · há 2 h')]));
}

class ActivityRow extends StatelessWidget {
	const ActivityRow({required this.icon, required this.color, required this.title, required this.detail, super.key});
	final IconData icon; final Color color; final String title, detail;
	@override
	Widget build(BuildContext context) {
		return Padding(
			padding: const EdgeInsets.only(bottom: 15),
			child: Row(children: [
				Container(padding: const EdgeInsets.all(8), decoration: BoxDecoration(color: color.withValues(alpha: .1), shape: BoxShape.circle), child: Icon(icon, color: color, size: 17)),
				const SizedBox(width: 10),
				Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(color: Color(0xFF3A2C42), fontSize: 12, fontWeight: FontWeight.w700)), const SizedBox(height: 3), Text(detail, style: const TextStyle(color: Color(0xFF8B808E), fontSize: 10))])),
			]),
		);
	}
}

class _WhitePanel extends StatelessWidget {
	const _WhitePanel({required this.title, required this.action, required this.child});
	final String title, action; final Widget child;
	@override
	Widget build(BuildContext context) {
		return Container(
			padding: const EdgeInsets.fromLTRB(20, 18, 20, 17),
			decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14), border: Border.all(color: const Color(0xFFE9E5ED))),
			child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
				Row(children: [Text(title, style: const TextStyle(color: Color(0xFF302137), fontSize: 14, fontWeight: FontWeight.w800)), const Spacer(), TextButton(onPressed: () {}, child: Text(action, style: const TextStyle(fontSize: 11)))]),
				const SizedBox(height: 12),
				child,
			]),
		);
	}
}

class ModulePage extends StatefulWidget {
	const ModulePage({required this.type, required this.role, super.key});
	final AppPage type;
	final UserRole role;
	@override
	State<ModulePage> createState() => _ModulePageState();
}

class _ModulePageState extends State<ModulePage> {
	final searchController = TextEditingController();
	final Map<AppPage, List<int>> _recordIds = {};
	Map<AppPage, List<List<String>>> _records = {
		AppPage.users: [['Mariana Alves', 'mariana@softmake.com', 'Proprietário', 'Ativo'], ['Carlos Souza', 'carlos@softmake.com', 'Vendedor', 'Ativo'], ['Ana Lima', 'ana@softmake.com', 'Atendente', 'Ativo']],
		AppPage.products: [['Café especial 500g', 'Cafés da Serra', 'R\$ 32,90', '8 un.', 'Baixo'], ['Açúcar refinado 1kg', 'Doce Vida', 'R\$ 5,49', '124 un.', 'Ativo'], ['Chá verde premium', 'Bela Folha', 'R\$ 18,90', '46 un.', 'Ativo']],
		AppPage.customers: [['Ricardo Mendes', '123.456.789-00', '(11) 99821-2234', 'Ativo'], ['Juliana Costa', '321.654.987-00', '(11) 98765-1000', 'Ativo'], ['João Pereira', '456.789.123-00', '(11) 97654-3000', 'Inativo']],
		AppPage.suppliers: [['Cafés da Serra Ltda.', 'Café Bom', '12.345.678/0001-90', 'Ativo'], ['Doce Vida Alimentos', 'Doce Vida', '98.765.432/0001-10', 'Ativo'], ['Bela Folha Produtos', 'Bela Folha', '45.123.789/0001-32', 'Ativo']],
		AppPage.sales: [['#00482', '14/09/2026 10:42', 'Carlos Souza', 'Pix', 'R\$ 128,40'], ['#00481', '14/09/2026 10:15', 'Ana Lima', 'Cartão', 'R\$ 276,90'], ['#00480', '14/09/2026 09:58', 'Carlos Souza', 'Dinheiro', 'R\$ 84,50']],
		AppPage.stock: [['Café especial 500g', 'Entrada', '+40 un.', '14/09/2026', 'Carlos Souza'], ['Açúcar refinado 1kg', 'Saída', '-12 un.', '14/09/2026', 'Ana Lima'], ['Chá verde premium', 'Entrada', '+20 un.', '13/09/2026', 'Mariana Alves']],
		AppPage.cash: [['Abertura de caixa', 'R\$ 500,00', '14/09/2026 08:00', 'Ana Lima'], ['Venda #00482', 'R\$ 128,40', '14/09/2026 10:42', 'Ana Lima'], ['Venda #00481', 'R\$ 276,90', '14/09/2026 10:15', 'Ana Lima']],
		AppPage.reports: [['Vendas por período', '01/09 a 14/09', 'R\$ 42.850,90', 'Gerar'], ['Produtos mais vendidos', 'Mês atual', '32 produtos', 'Gerar'], ['Movimentações do caixa', '14/09/2026', '24 lançamentos', 'Gerar']],
	};

	@override
	void initState() {
		super.initState();
		_loadRecords();
	}

	Future<void> _loadRecords() async {
		final loaded = <AppPage, List<List<String>>>{};
		for (final page in AppPage.values) {
			if (page == AppPage.charter || page == AppPage.overview) {
				continue;
			}
			final rows = await AppDatabase.instance.getRecords(_moduleNameForPage(page));
			if (rows.isEmpty) {
				final initialRows = _records[page] ?? const <List<String>>[];
				final ids = <int>[];
				for (final initialRow in initialRows) {
					ids.add(await AppDatabase.instance.insertRecord(_moduleNameForPage(page), initialRow));
				}
				loaded[page] = initialRows;
				_recordIds[page] = ids;
			} else {
				loaded[page] = rows.map((row) => List<String>.from(jsonDecode(row['values_json'] as String) as List)).toList();
				_recordIds[page] = rows.map((row) => row['id'] as int).toList();
			}
		}

		if (!mounted) return;
		setState(() {
			_records = {..._records, ...loaded};
		});
	}

	String _moduleNameForPage(AppPage page) => switch (page) {
		AppPage.users => 'users',
		AppPage.products => 'products',
		AppPage.customers => 'customers',
		AppPage.suppliers => 'suppliers',
		AppPage.sales => 'sales',
		AppPage.stock => 'stock',
		AppPage.cash => 'cash',
		AppPage.reports => 'reports',
		AppPage.management => 'management',
		_ => 'misc',
	};

	String get title => navItems.firstWhere((item) => item.page == widget.type).label;
	IconData get icon => navItems.firstWhere((item) => item.page == widget.type).icon;
	List<String> get headers => switch (widget.type) { AppPage.users => ['Nome', 'E-mail', 'Perfil', 'Status'], AppPage.products => ['Produto', 'Marca', 'Preço', 'Estoque', 'Status'], AppPage.customers => ['Nome', 'CPF', 'Telefone', 'Status'], AppPage.suppliers => ['Razão social', 'Nome fantasia', 'CNPJ', 'Status'], AppPage.sales => ['Código', 'Data', 'Vendedor', 'Pagamento', 'Total'], AppPage.stock => ['Produto', 'Movimentação', 'Quantidade', 'Data', 'Responsável'], AppPage.cash => ['Movimentação', 'Valor', 'Data', 'Responsável'], AppPage.reports => ['Relatório', 'Período', 'Resultado', 'Ação'], AppPage.management => ['Indicador', 'Período', 'Resultado', 'Responsável'], _ => [] };

	@override
	Widget build(BuildContext context) {
		final allData = _records[widget.type] ?? [];
		final query = searchController.text.trim().toLowerCase();
		final visibleEntries = allData.asMap().entries.where((entry) => query.isEmpty || entry.value.any((value) => value.toLowerCase().contains(query))).toList();
		return LayoutBuilder(builder: (context, constraints) => SingleChildScrollView(padding: EdgeInsets.all(constraints.maxWidth < 600 ? 16 : 30), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
			Row(children: [Container(padding: const EdgeInsets.all(11), decoration: BoxDecoration(color: const Color(0xFFEDE2F4), borderRadius: BorderRadius.circular(12)), child: Icon(icon, color: const Color(0xFF64218E))), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(color: Color(0xFF2C1A35), fontSize: 21, fontWeight: FontWeight.w800)), Text(_description, style: const TextStyle(color: Color(0xFF817584), fontSize: 12))])), FilledButton.icon(onPressed: () => _showAddDialog(context), icon: const Icon(Icons.add, size: 18), label: Text(widget.type == AppPage.reports ? 'Novo relatório' : 'Adicionar'))]),
			const SizedBox(height: 22),
			Row(children: [Expanded(child: TextField(controller: searchController, onChanged: (_) => setState(() {}), decoration: const InputDecoration(hintText: 'Buscar registros...', prefixIcon: Icon(Icons.search, size: 19)))), const SizedBox(width: 10), OutlinedButton.icon(onPressed: () {}, icon: const Icon(Icons.filter_list, size: 18), label: const Text('Filtros'))]),
			const SizedBox(height: 16),
			Container(
				width: double.infinity,
				decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14), border: Border.all(color: const Color(0xFFE9E5ED))),
				child: SingleChildScrollView(
					scrollDirection: Axis.horizontal,
					child: DataTable(
						headingRowColor: WidgetStateProperty.all(const Color(0xFFFAF8FC)),
						dataRowMinHeight: 60,
						dataRowMaxHeight: 64,
						columnSpacing: 32,
						columns: [...headers, if (_canEdit) 'Ações'].map((header) => DataColumn(label: Text(header, style: const TextStyle(color: Color(0xFF6E6173), fontSize: 11, fontWeight: FontWeight.w800)))).toList(),
						rows: visibleEntries.map((rowEntry) {
							final row = rowEntry.value;
							final cells = row.asMap().entries.map((entry) {
								final isStatus = entry.key == row.length - 1 && row.isNotEmpty && widget.type != AppPage.sales && widget.type != AppPage.stock && widget.type != AppPage.cash && widget.type != AppPage.reports;
								return DataCell(isStatus ? _StatusPill(text: entry.value) : Text(entry.value, style: const TextStyle(color: Color(0xFF413747), fontSize: 12)));
							}).toList();
							if (_canEdit) {
								cells.add(DataCell(Row(mainAxisSize: MainAxisSize.min, children: [
									IconButton(tooltip: 'Editar', onPressed: () => _showEditDialog(context, rowEntry.key, row), icon: const Icon(Icons.edit_outlined, size: 18)),
									IconButton(tooltip: 'Excluir', onPressed: () => _deleteRecord(rowEntry.key), icon: const Icon(Icons.delete_outline, size: 18, color: Color(0xFFB3261E))),
								])));
							}
							return DataRow(cells: cells);
						}).toList(),
					),
				),
			),
		])));
	}

	bool get _canEdit => widget.role == UserRole.owner;

	String get _description => switch (widget.type) { AppPage.users => 'Controle de acesso e perfis da equipe', AppPage.products => 'Produtos comercializados e seus status', AppPage.customers => 'Cadastros e histórico de clientes', AppPage.suppliers => 'Empresas que fornecem produtos à SoftMake', AppPage.sales => 'Registro e consulta de vendas realizadas', AppPage.stock => 'Entradas, saídas e alertas de estoque', AppPage.cash => 'Movimentações e fechamento do caixa', AppPage.reports => 'Informações para apoiar decisões gerenciais', AppPage.management => 'Indicadores e configurações administrativas', _ => '' };

	void _showAddDialog(BuildContext context) {
		_showRecordDialog(context);
	}

	void _showEditDialog(BuildContext context, int index, List<String> values) {
		_showRecordDialog(context, index: index, initialValues: values);
	}

	Future<void> _deleteRecord(int index) async {
		final id = _recordIds[widget.type]?[index];
		if (id == null) return;
		final confirmed = await showDialog<bool>(context: context, builder: (context) => AlertDialog(title: const Text('Excluir registro?'), content: const Text('Essa ação não pode ser desfeita.'), actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')), FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Excluir'))])) ?? false;
		if (!confirmed) return;
		await AppDatabase.instance.deleteRecord(id);
		if (!mounted) return;
		setState(() {
			_records[widget.type]?.removeAt(index);
			_recordIds[widget.type]?.removeAt(index);
		});
	}

	void _showRecordDialog(BuildContext context, {int? index, List<String>? initialValues}) {
		final fields = switch (widget.type) {
			AppPage.users => ['Nome', 'E-mail', 'Perfil', 'Status'],
			AppPage.products => ['Produto', 'Marca', 'Preço', 'Estoque', 'Status'],
			AppPage.customers => ['Nome', 'CPF', 'Telefone', 'Status'],
			AppPage.suppliers => ['Razão social', 'Nome fantasia', 'CNPJ', 'Status'],
			AppPage.sales => ['Código', 'Data', 'Vendedor', 'Pagamento', 'Total'],
			AppPage.stock => ['Produto', 'Movimentação', 'Quantidade', 'Data', 'Responsável'],
			AppPage.cash => ['Movimentação', 'Valor', 'Data', 'Responsável'],
			AppPage.reports => ['Relatório', 'Período', 'Resultado', 'Ação'],
			AppPage.management => ['Indicador', 'Período', 'Resultado', 'Responsável'],
			_ => ['Nome ou descrição'],
		};

		final controllers = fields.asMap().entries.map((entry) => TextEditingController(text: initialValues != null && entry.key < initialValues.length ? initialValues[entry.key] : '')).toList();
		showDialog<void>(
			context: context,
			builder: (context) {
				return AlertDialog(
									title: Text('${index == null ? 'Adicionar em' : 'Editar em'} $title'),
					content: SizedBox(
						width: 430,
						child: SingleChildScrollView(
							child: Column(
								mainAxisSize: MainAxisSize.min,
								children: [
									for (var i = 0; i < fields.length; i++)
										Padding(
											padding: const EdgeInsets.only(bottom: 12),
											child: TextField(
												controller: controllers[i],
												decoration: InputDecoration(labelText: fields[i]),
											),
										),
								],
							),
						),
					),
					actions: [
						TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')),
						FilledButton(
							onPressed: () async {
								final values = controllers
									.map((controller) => controller.text.trim())
									.toList();

								if (values.every((value) => value.isEmpty)) {
									Navigator.pop(context);
									return;
								}

								final normalizedValues = List<String>.from(values);
								if (normalizedValues.length == 1 && normalizedValues[0].isNotEmpty) {
									normalizedValues[0] = normalizedValues[0];
								} else if (normalizedValues.isNotEmpty && normalizedValues.last.trim().isEmpty) {
									normalizedValues[normalizedValues.length - 1] = 'Ativo';
								}

								try {
																	if (index == null) {
																		final id = await AppDatabase.instance.insertRecord(_moduleNameForPage(widget.type), normalizedValues);
																		_recordIds[widget.type] = [id, ...(_recordIds[widget.type] ?? [])];
																	} else {
																		final id = _recordIds[widget.type]?[index];
																		if (id != null) await AppDatabase.instance.updateRecord(id, normalizedValues);
																	}
									if (!mounted) return;
									setState(() {
																		if (index == null) {
																			_records[widget.type] = [normalizedValues, ...(_records[widget.type] ?? [])];
																		} else {
																			_records[widget.type]?[index] = normalizedValues;
																		}
									});
									if (!context.mounted) return;
									Navigator.pop(context);
								} catch (_) {
									if (!mounted) return;
									Navigator.pop(context);
								}
							},
							child: const Text('Salvar'),
						),
					],
				);
			},
		);
	}
}

class _StatusPill extends StatelessWidget {
	const _StatusPill({required this.text});
	final String text;
	@override
	Widget build(BuildContext context) { final active = text == 'Ativo' || text == 'Aberto'; final low = text == 'Baixo'; final color = active ? const Color(0xFF16866C) : low ? const Color(0xFFD78322) : const Color(0xFF8C5D99); return Container(padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5), decoration: BoxDecoration(color: color.withValues(alpha: .11), borderRadius: BorderRadius.circular(20)), child: Text(text, style: TextStyle(color: color, fontSize: 10, fontWeight: FontWeight.w800))); }
}

class CharterPage extends StatelessWidget {
	const CharterPage({super.key});
	@override
	Widget build(BuildContext context) => SingleChildScrollView(
		padding: const EdgeInsets.all(30),
		child: Center(
			child: ConstrainedBox(
				constraints: const BoxConstraints(maxWidth: 980),
				child: Container(
					padding: const EdgeInsets.all(30),
					decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14), border: Border.all(color: const Color(0xFFE9E5ED))),
					child: const Column(
						crossAxisAlignment: CrossAxisAlignment.start,
						children: [
							Text('Termo de abertura do projeto', style: TextStyle(color: Color(0xFF3C1B4D), fontSize: 25, fontWeight: FontWeight.w800)),
							SizedBox(height: 8),
							Text('SOFTMAKE LTDA · Documento base do sistema de gestão', style: TextStyle(color: Color(0xFF8A7C8D), fontSize: 12)),
							SizedBox(height: 28),
							CharterSection(title: 'Objetivo do projeto', text: 'A SOFTMAKE LTDA necessita informatizar seus processos para obter maior controle de suas atividades, automatizando suas rotinas diárias para aumentar a produtividade, reduzir erros e facilitar o acesso às informações da empresa.'),
							CharterSection(title: 'Escopo da solução', text: 'O sistema contempla o gerenciamento de usuários, produtos, clientes, fornecedores, vendas, estoque, caixa, consultas e relatórios gerenciais. A aplicação será responsiva e acessível por computadores, tablets e smartphones conectados à Internet.'),
							CharterSection(title: 'Tecnologia e disponibilidade', text: 'O front-end e a lógica serão desenvolvidos com Flutter e Dart, com armazenamento relacional local utilizando SQflite. A interface será moderna, intuitiva e amigável, permanecendo disponível para uso 24 horas por dia conforme as permissões de cada usuário.'),
							CharterSection(title: 'Perfis de acesso', text: 'Proprietário: acesso completo, incluindo usuários, produtos, informações administrativas e relatórios. Vendedor: consulta produtos e estoque, gerencia clientes e registra vendas. Atendente: consulta produtos e clientes, registra vendas e recebimentos, acompanha movimentações e fecha o caixa.'),
							CharterSection(title: 'Resultado esperado', text: 'Uma solução centralizada para organizar informações, reduzir atividades manuais, controlar estoque, acompanhar vendas e caixa e gerar dados para a tomada de decisões, com segurança e possibilidade de futuras expansões.'),
							SizedBox(height: 8),
							Text('Requisitos funcionais contemplados', style: TextStyle(color: Color(0xFF3C1B4D), fontSize: 17, fontWeight: FontWeight.w800)),
							SizedBox(height: 12),
							Wrap(spacing: 8, runSpacing: 8, children: [RequirementTag(label: 'RF001 · Login'), RequirementTag(label: 'RF002–RF005 · Clientes'), RequirementTag(label: 'RF006–RF008 · Produtos'), RequirementTag(label: 'RF009–RF012 · Funcionários'), RequirementTag(label: 'RF013–RF016 · Fornecedores'), RequirementTag(label: 'RF017–RF020 · Vendas'), RequirementTag(label: 'RF021–RF024 · Estoque'), RequirementTag(label: 'RF025–RF028 · Caixa'), RequirementTag(label: 'RF029–RF031 · Gerência')]),
						],
					),
				),
			),
		),
	);
}

class CharterSection extends StatelessWidget {
	const CharterSection({required this.title, required this.text, super.key});
	final String title, text;
	@override
	Widget build(BuildContext context) => Padding(padding: const EdgeInsets.only(bottom: 22), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(color: Color(0xFF5C1E91), fontSize: 15, fontWeight: FontWeight.w800)), const SizedBox(height: 6), Text(text, style: const TextStyle(color: Color(0xFF554A58), height: 1.55, fontSize: 13))]));
}

class RequirementTag extends StatelessWidget {
	const RequirementTag({required this.label, super.key});
	final String label;
	@override
	Widget build(BuildContext context) => Container(padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 8), decoration: BoxDecoration(color: const Color(0xFFF2EBF6), borderRadius: BorderRadius.circular(8)), child: Text(label, style: const TextStyle(color: Color(0xFF64218E), fontSize: 11, fontWeight: FontWeight.w700)));
}
