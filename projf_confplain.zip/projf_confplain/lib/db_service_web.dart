import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

class AppDatabase {
  AppDatabase._();

  static final AppDatabase instance = AppDatabase._();
  static const _prefix = 'softmake_web_records_';

  Future<List<Map<String, dynamic>>> getRecords(String module) async {
    final preferences = await SharedPreferences.getInstance();
    final decoded = jsonDecode(preferences.getString('$_prefix$module') ?? '[]');
    return (decoded as List).cast<Map>().map((row) => Map<String, dynamic>.from(row)).toList();
  }

  Future<int> insertRecord(String module, List<String> values) async {
    final records = await getRecords(module);
    final id = DateTime.now().microsecondsSinceEpoch;
    records.insert(0, {'id': id, 'values_json': jsonEncode(values)});
    await _save(module, records);
    return id;
  }

  Future<int> updateRecord(int id, List<String> values) async {
    final module = await _findModule(id);
    if (module == null) return 0;
    final records = await getRecords(module);
    final index = records.indexWhere((row) => row['id'] == id);
    if (index < 0) return 0;
    records[index]['values_json'] = jsonEncode(values);
    await _save(module, records);
    return 1;
  }

  Future<int> deleteRecord(int id) async {
    final module = await _findModule(id);
    if (module == null) return 0;
    final records = await getRecords(module);
    records.removeWhere((row) => row['id'] == id);
    await _save(module, records);
    return 1;
  }

  Future<String?> _findModule(int id) async {
    final preferences = await SharedPreferences.getInstance();
    for (final key in preferences.getKeys().where((key) => key.startsWith(_prefix))) {
      final records = jsonDecode(preferences.getString(key) ?? '[]') as List;
      if (records.any((row) => row['id'] == id)) return key.substring(_prefix.length);
    }
    return null;
  }

  Future<void> _save(String module, List<Map<String, dynamic>> records) async {
    final preferences = await SharedPreferences.getInstance();
    await preferences.setString('$_prefix$module', jsonEncode(records));
  }
}